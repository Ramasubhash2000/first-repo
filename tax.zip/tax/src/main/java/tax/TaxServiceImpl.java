package tax;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class TaxServiceImpl implements TaxService {
	
	//@Override
	public Map getTaxs(int salary)
	{
		Map<String, Object> map=new HashMap<>();
		int tax1 = 0;int tax2=0;int tax3=0;int tax4=0;
		int total=0;
		  if (salary > 250000)
		  {
		    if (salary > 500000)
		    {
		      tax2 = 12500;
		      if (salary > 1000000)
		      {
		    	  tax3=50000;
		    	  tax4=(((salary - 1000000)*20)/100);
		         total = tax3+tax2+tax4+tax1;
		      }
		      else
		      {
		    	  tax3= (((salary - 500000)*10)/100);
		           total = tax2+tax3;
		       
		      }
		    }
		    else
		    {
		      tax2 = ((salary - 250000)*5)/100;
		       total = tax2;
		    }
		  }
		  else
		  {
		    tax1 = 0;
		  }
		  map.put("salary", salary);
		  map.put("tax1", tax1);
		  map.put("tax2", tax2);
		  map.put("tax3", tax3);
		  map.put("tax4", tax4);
		  map.put("total", total);
		  
		  return map;

	}

}
