package tax;

public class Taxx {
	
	private int salary;
	private int tax1=0;int tax2=0;int tax3=0;int tax4=0;
	private int total;
	//private int sum;
	
	
	/*public Taxx() {
		super();
	}

	public Taxx(int salary, int tax) {
		super();
		this.salary = salary;
		this.tax = tax;
		//this.sum = sum;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getTax() {
		return tax;
	}

	public void setTax(int tax) {
		this.tax = tax;
	}*/


}
