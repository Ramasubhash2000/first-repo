package tax;

import java.util.Map;

public interface TaxService {
	
	Map<String, Object> getTaxs(int salary);
    }


