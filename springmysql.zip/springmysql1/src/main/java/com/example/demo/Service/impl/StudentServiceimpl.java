package com.example.demo.Service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.example.demo.Exception.RecordNotFoundException;
import com.example.demo.Repository.StudentRepository;
import com.example.demo.Service.StudentService;
import com.example.demo.model.Student;


@Service
public class StudentServiceimpl implements StudentService{
	
	@Autowired
	private StudentRepository studentRepository;
	
	//Post student
	@Override
	public ResponseEntity<Object> savestudent(Student student){
		Student s=studentRepository.findByMail(student.getMail());
		if(s!=null)
		{
			Object o = "Email already exists";
			return ResponseEntity.badRequest().body(o);

		}
		else
		{
		
			return ResponseEntity.ok().body(studentRepository.save(student));
	    }
	}

	//get all students
	@Override
	public List<Student> getAllStudent() {
		return studentRepository.findAll();
	}


	//Delete 
	@Override
	public void deleteStudent(long id) {
		studentRepository.deleteById(id);
	}


   //Get by Id
	public Student getStudentById(long id) throws RecordNotFoundException {
	return studentRepository.findById(id).orElseThrow(() ->
	      new RecordNotFoundException("Student with given id does not exist" ));
	}
	
	
     //PUT mapping
	public Student updateStudent(Student student, long id) throws RecordNotFoundException {
		// check if given student is existing or not
		Student existingStudent=studentRepository.findById(id).orElseThrow(() ->
		  new RecordNotFoundException("Student with given id does not exist"));
		
		existingStudent.setFname(student.getFname());
		existingStudent.setLname(student.getLname());
		existingStudent.setMail(student.getMail());

		//save existing student to Database
		studentRepository.save(existingStudent);
		return existingStudent;
	}
	//pagination
    @Override
	public Page<Student> findPaginated(int pageNo, int pageSize) {
		Pageable pageable = PageRequest.of(pageNo, pageSize);
		return this.studentRepository.findAll(pageable);
	}

    //sorting by letter
	@Override
	public List<Student> findByName(String search) {
		return this.studentRepository.findByName(search);
		
	}
	
   
		
	}




