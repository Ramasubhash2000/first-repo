package com.example.demo.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
@Entity(name = "students")
@Table(name="students")
public class Student {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	//@NotNull
	//@NotBlank
	@NotEmpty(message="Please enter first name")
	@Column
	//@Size(message = "please enter the first name")
	private String fname;
	
	@NotEmpty(message="Please enter last name")
	@Column
	//(unique=true,columnDefinition="please enter a unique name")
	private String lname;
	
	//@Email(message = "Please enter a valid email id")
	@NotEmpty(message="Please enter mailid")
	@Pattern(regexp="^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$+",message="invalid email")
	//@Pattern(regexp = "^[0-9]{10}$+",message="invalid phone")
	@Column
	private String mail;

	public Student() {
		super();
	}
	
	public Student(int id, String fname, String lname, String mail) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.mail = mail;
		
		
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}	
	
}
