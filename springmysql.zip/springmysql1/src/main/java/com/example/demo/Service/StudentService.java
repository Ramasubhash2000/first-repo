package com.example.demo.Service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;

import com.example.demo.Exception.RecordNotFoundException;
import com.example.demo.model.Student;

public interface StudentService{
	ResponseEntity<?> savestudent(Student student);
	List<Student> getAllStudent();
	Student getStudentById(long id) throws RecordNotFoundException;
	Student updateStudent(Student student,long id) throws RecordNotFoundException;
		void deleteStudent(long id);
		Page<Student> findPaginated(int pageNo, int pageSize);
	    List<Student> findByName(@Param("search")String search);

}
