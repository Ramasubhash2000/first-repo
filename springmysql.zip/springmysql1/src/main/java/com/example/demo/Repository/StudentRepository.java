package com.example.demo.Repository;

import java.util.List;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.model.Student;

public interface StudentRepository extends JpaRepository <Student, Long>{
	
	 Student findByMail(String mail);
	 
	 
	//sorting for first name
	 @Query("select s from students s where fname like CONCAT('%',:search,'%') or lname like CONCAT('%',:search,'%')")
	    List<Student> findByName(@Param("search")String search);
}
