package com.example.demo.Exception;

import java.util.List;

public class ErrorResponse  {

	public ErrorResponse(String message, int status,List<String>errors) {
		    super();
		    this.message = message;
		    this.status = status;
		    this.errors= errors;
		  }
		 
		  //General error message about nature of error
		  private String message;
		  private List<String> errors;
          private int status;
		  
		//Getter and setters

		public String getMessage() {
			return message;
		}
		
		public List<String> getErrors() {
			return errors;
		}
		
		public int getStatus() {
			return status;
		}

}
		 
		  
		  