package com.example.demo.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Exception.RecordNotFoundException;
import com.example.demo.Service.StudentService;

import com.example.demo.model.Student;

@RestController
@RequestMapping("/students")
public class StudentController {
	
	@Autowired
	private StudentService studentservice;

	// create student REST API
	@PostMapping()
	public ResponseEntity<?> saveStudent(@Valid @RequestBody Student student){
		return ResponseEntity.ok().body(studentservice.savestudent(student));	}
	

	//Get all students REST API
	@GetMapping
	List<Student> getAllStudent(){
	return studentservice.getAllStudent();
	}
	
	//Get student id by REST API
		@GetMapping("{id}")
		public ResponseEntity<?> getStudentById(@PathVariable("id")long studentId) throws Exception{
			return ResponseEntity.ok(studentservice.getStudentById(studentId));
			
		}
		
		//update student RESTAPI
		@PutMapping("/{id}")
		public ResponseEntity<?>updateStudent(@Valid@PathVariable("id")long id 
				,@RequestBody Student student) throws RecordNotFoundException{
			return ResponseEntity.ok(studentservice.updateStudent(student, id));
			
		}
	
    //delete student RESTAPI
	@DeleteMapping("{id}")
	public Map<String, String>deleteStudent(@PathVariable()long id) throws Exception{
		 studentservice.deleteStudent(id);
		 Map<String, String> response = new HashMap<>();
	        response.put("deleted", "Student details deleted Successfully");
	        return response;
	
		
	}
	
	//get no of students using pagination
	@GetMapping("/page")
	public List<Student> findPaginated(@RequestParam(value="pageNo") int pageNo, @RequestParam(value="pageSize") int pageSize){

		Page<Student> page = studentservice.findPaginated(pageNo, pageSize);
		List<Student> liststudent = page.getContent();
     if (pageSize > liststudent.size()) {
	      throw new RecordNotFoundException("records not found");
	}
     
else {
		return liststudent ;
		
	}
	}

	//sorting 
	@GetMapping("/")
	public List<Student> getStudent(@RequestParam(value="fn") String fn){
	return  studentservice.findByName(fn);

	}
	
}


